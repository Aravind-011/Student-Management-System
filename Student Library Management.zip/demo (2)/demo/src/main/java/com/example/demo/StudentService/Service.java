package com.example.demo.StudentService;

import com.example.demo.Repo.StudentRepo;
import com.example.demo.model.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Service {
     @Autowired
     private StudentRepo studentrepo;

    public Student studentSave(Student student){
        return  studentrepo.save(student);
    }
}
