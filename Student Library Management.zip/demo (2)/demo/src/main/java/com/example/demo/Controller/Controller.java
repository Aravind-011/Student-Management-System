package com.example.demo.Controller;

import com.example.demo.StudentService.Service;
import com.example.demo.model.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/student")
@CrossOrigins
public class Controller {
    @Autowired
    private Service service;
    @PostMapping("/add")
    public String add(@RequestBody Student student){
        service.studentSave(student);
        return "new Student added";


    }

}
